export const questions = [
  {
    "id": 1,
    "q": "Apa dasar hukum yang menetapkan bahwa Bawaslu bertugas melakukan pencegahan dan penindakan terhadap pelanggaran serta sengketa proses Pemilu?",
    "options": [
      "Undang-Undang Nomor 23 Tahun 2014",
      "Undang-Undang Nomor 7 Tahun 2017",
      "Peraturan Presiden Nomor 11 Tahun 2019",
      "Keputusan Presiden Nomor 10 Tahun 2023"
    ],
    "correctOption": 1
  },
  {
    "id": 2,
    "q": "Berikut ini yang bukan termasuk dalam 7 bentuk strategi pencegahan Bawaslu adalah:",
    "options": [
      "Partisipasi masyarakat",
      "Pendidikan",
      "Penegakan hukum pidana",
      "Identifikasi kerawanan"
    ],
    "correctOption": 2
  },
  {
    "id": 3,
    "q": "Keikutsertaan masyarakat dalam mengawasi jalannya Pemilu untuk menjaga keadilan dan transparansi dikenal dengan istilah:",
    "options": [
      "Masyarakat Partisipan",
      "Partisipasi Masyarakat",
      "Pengawasan partisipatif",
      "Rakyat Berkolaborasi"
    ],
    "correctOption": 2
  },
  {
    "id": 4,
    "q": "Strategi pencegahan pelanggaran Pemilu oleh Bawaslu dilakukan melalui berbagai pendekatan. Manakah dari berikut ini yang bukan termasuk pendekatan strategis tersebut?",
    "options": [
      "Imbauan",
      "Publikasi",
      "Penindakan langsung",
      "Kolaborasi"
    ],
    "correctOption": 2
  },
  {
    "id": 5,
    "q": "Berikut ini adalah strategi pencegahan pelanggaran dan sengketa proses Pemilu menurut pedoman Bawaslu:\n1. Identifikasi kerawanan\n2. Pendidikan\n3. Partisipasi masyarakat\n4. Kerja sama\n5. Naskah dinas\n6. Publikasi\n7. Kegiatan lain\nDari daftar di atas, manakah pernyataan yang benar mengenai strategi tersebut?",
    "options": [
      "Hanya nomor 1, 2, dan 4 yang termasuk strategi pencegahan",
      "Nomor 5 (naskah dinas) tidak termasuk strategi pencegahan",
      "Strategi hanya mencakup upaya pendidikan dan publikasi",
      "Semua poin 1 sampai 7 merupakan bagian dari strategi pencegahan"
    ],
    "correctOption": 3
  },
  {
    "id": 6,
    "q": "Apa saja jenis pelanggaran Pemilu menurut Undang-Undang Nomor 7 Tahun 2017?",
    "options": [
      "Pelanggaran administratif, pelanggaran hukum adat, dan pelanggaran sosial",
      "Pelanggaran kode etik, pelanggaran perdata Pemilu, pelanggaran pidana, dan pelanggaran administratif",
      "Pelanggaran administratif, tindak pidana Pemilu, dan pelanggaran kode etik penyelenggara Pemilu",
      "Pelanggaran etik, pelanggaran hukum internasional, pelanggaran kampanye, dan pelanggaran pidana"
    ],
    "correctOption": 2
  },
  {
    "id": 7,
    "q": "Kapan laporan dugaan pelanggaran Pemilu tidak dapat dicabut oleh pelapor?",
    "options": [
      "Jika belum memenuhi syarat formal",
      "Jika belum ada klarifikasi",
      "Jika laporan sudah diregistrasi oleh Pengawas Pemilu",
      "Jika pelapor belum menyertakan bukti"
    ],
    "correctOption": 2
  },
  {
    "id": 8,
    "q": "Berikut ini yang merupakan salah satu syarat materiil dalam laporan dugaan pelanggaran Pemilu adalah…",
    "options": [
      "Nama dan alamat pelapor",
      "Identitas pihak terlapor",
      "Waktu penyampaian laporan",
      "Bukti dugaan pelanggaran"
    ],
    "correctOption": 3
  },
  {
    "id": 9,
    "q": "Dalam hal laporan dugaan pelanggaran administratif Pemilu yang bersifat Terstruktur, Sistematis, dan Masif (TSM), maka laporan hanya dapat diproses jika…",
    "options": [
      "Terjadi kekerasan dalam kampanye",
      "Terdapat lebih dari tiga pelapor",
      "Terjadi di minimal 25% wilayah pemilihan",
      "Terjadi di minimal 50% wilayah atau daerah pemilihan"
    ],
    "correctOption": 3
  },
  {
    "id": 10,
    "q": "Jika seseorang menyampaikan laporan dugaan pelanggaran Pemilu melalui aplikasi Sigap Lapor dan memenuhi syarat pelaporan tetapi tidak datang ke kantor pengawas dalam waktu 2 hari setelah pelaporan daring, maka laporan tersebut akan:",
    "options": [
      "Tetap diregistrasi dan diproses",
      "Dihapus secara otomatis",
      "Menjadi informasi awal",
      "Dianggap pelaporan ganda"
    ],
    "correctOption": 2
  },
  {
    "id": 11,
    "q": "Apa yang menjadi penyebab utama timbulnya sengketa proses Pemilu antara peserta dengan penyelenggara Pemilu?",
    "options": [
      "Ketidaksetujuan terhadap hasil rekapitulasi suara",
      "Tindakan kampanye hitam oleh peserta lain",
      "Keputusan KPU yang merugikan peserta secara langsung",
      "Pelanggaran administratif oleh peserta"
    ],
    "correctOption": 2
  },
  {
    "id": 12,
    "q": "Alur penyelesaian sengketa antara peserta Pemilu dengan penyelenggara Pemilu mencakup tahapan berikut, kecuali:",
    "options": [
      "Penerimaan dan registrasi",
      "Klarifikasi dan verifikasi data pemilih",
      "Mediasi",
      "Adjudikasi dan putusan"
    ],
    "correctOption": 1
  },
  {
    "id": 13,
    "q": "Berapa batas waktu maksimal peserta Pemilu dapat mengajukan permohonan PSPP sejak tanggal penetapan keputusan KPU?",
    "options": [
      "1 hari",
      "3 hari",
      "5 hari",
      "7 hari"
    ],
    "correctOption": 1
  },
  {
    "id": 14,
    "q": "Permohonan penyelesaian sengketa antar peserta Pemilu dapat disampaikan secara lisan. Dalam hal ini, apa yang dilakukan oleh pengawas Pemilu?",
    "options": [
      "Menolak permohonan",
      "Merekam video sebagai bukti",
      "Mencatat dalam formulir resmi",
      "Meneruskan ke kepolisian"
    ],
    "correctOption": 2
  },
  {
    "id": 15,
    "q": "Permohonan penyelesaian sengketa proses Pemilu tidak dapat diregister jika…",
    "options": [
      "Permohonan disampaikan secara daring",
      "Berkas permohonan dinyatakan belum lengkap dan tidak dilengkapi dalam waktu 3 hari",
      "Objek sengketa berupa SK KPU",
      "Permohonan disusun tanpa menggunakan kuasa hukum"
    ],
    "correctOption": 1
  },
  {
    "id": 16,
    "q": "Manakah dari pilihan berikut yang bukan termasuk contoh pengembangan gerakan pengawasan partisipatif dalam Pemilu?",
    "options": [
      "Pengembangan Kader Pengawas Partisipatif",
      "Pengembangan Kampung Pengawasan Partisipatif",
      "Pengembangan Pojok Pengawasan",
      "Pendirian Organisasi Masyarakat"
    ],
    "correctOption": 3
  },
  {
    "id": 17,
    "q": "Tujuan dari pengawasan partisipatif jangka panjang dalam konteks political change adalah:",
    "options": [
      "Memenangkan partai tertentu dalam Pemilu",
      "Merubah kemungkinan kemenangan dari suatu partai politik",
      "Merubah kebijakan, institusi, dan perilaku masyarakat secara berkelanjutan",
      "Menjadikan kepentingan politik sebagai dasar dalam melaksanakan pengawasan partisipatif"
    ],
    "correctOption": 2
  },
  {
    "id": 18,
    "q": "Di bawah ini adalah pengembangan pengawasan partisipatif: yakni\n1) edukasi secara aktif tentang kepemiluan;\n2) konsolidasi jaringan;\n3) mengampanyekan gagasan;\n4) menjadi penggerak forum;\n5) melakukan pemberdayaan komunitas.\nLevel pengembangan pengawasan partisipatif tersebut adalah:",
    "options": [
      "terlatih dan terbentuk",
      "Berfungsi",
      "Bergerak",
      "Berfungsi dan bergerak"
    ],
    "correctOption": 3
  },
  {
    "id": 19,
    "q": "Teknis pengembangan gerakan pengawasan partisipatif adalah sebagai berikut:",
    "options": [
      "pemberdayaan, partisipasi aktif, pengembangan kapasitas, pendekatan jaringan pemimpin",
      "pemberdayaan, partisipasi aktif, pengembangan kapasitas, pendekatan holistik, penggunaan sumber daya lokal",
      "pemberdayaan, partisipasi aktif, pengembangan kapasitas, perluasan elektabilitas dan popularitas",
      "semua jawaban benar"
    ],
    "correctOption": 1
  },
  {
    "id": 20,
    "q": "Salah satu bentuk kerja sama Bawaslu dengan perguruan tinggi dalam pengawasan partisipatif adalah:",
    "options": [
      "Menyediakan dana kampanye bagi mahasiswa",
      "Mengangkat dosen sebagai anggota KPU",
      "Kuliah kerja nyata tematik tentang pengawasan Pemilu",
      "Memberikan suara secara kolektif di kampus"
    ],
    "correctOption": 2
  },
  {
    "id": 21,
    "q": "Apa esensi utama dari teknis penguatan jaringan dalam pengawasan Pemilu?",
    "options": [
      "Menyebarkan informasi sebanyak mungkin kepada komunitas",
      "Membentuk lembaga baru untuk memperkuat pengawasan",
      "Memfasilitasi integrasi potensi komunitas guna membangun jejaring kerja yang strategis",
      "Mendorong komunitas bekerja secara independen tanpa intervensi luar"
    ],
    "correctOption": 2
  },
  {
    "id": 22,
    "q": "Salah satu syarat penting dalam membangun jejaring komunitas yang kuat adalah “kepercayaan (trust)”. Kepercayaan dibangun melalui:",
    "options": [
      "Kepemilikan saham bersama antar komunitas untuk dibagi hasil",
      "Struktur organisasi informal yang fleksibel serta tugas dan fungsi yang hanya diterapkan pada salah satu anggota",
      "SDM yang memadai dan struktur organisasi yang jelas",
      "Kontrak tertulis antara pemimpin komunitas"
    ],
    "correctOption": 2
  },
  {
    "id": 23,
    "q": "Pendekatan Asset Based Community Development (ABCD) yang digunakan dalam pemberdayaan komunitas menekankan pada:",
    "options": [
      "Fokus pada masalah komunitas dan penyelesaiannya dari luar",
      "Pemanfaatan potensi dan aset lokal sebagai dasar pengembangan",
      "Pengabaian struktur sosial lokal yang ada",
      "Pendanaan besar dari pemerintah pusat sebagai syarat pemberdayaan"
    ],
    "correctOption": 1
  },
  {
    "id": 24,
    "q": "Teknologi digital berperan penting dalam penguatan jaringan komunitas karena:",
    "options": [
      "Memperluas jangkauan kolaborasi dan mempermudah penyebaran informasi",
      "Memungkinkan pengawasan dilakukan secara sepihak oleh Bawaslu",
      "Menggantikan fungsi komunikasi langsung dan tatap muka",
      "Menghindarkan komunitas dari intervensi pihak luar"
    ],
    "correctOption": 0
  },
  {
    "id": 25,
    "q": "Di bawah ini yang bukan merupakan langkah pemberdayaan komunitas, adalah:",
    "options": [
      "Identifikasi kebutuhan dan potensi komunitas",
      "Mendorong mobilisasi masyarakat",
      "Memberikan pelatihan dan pendidikan berkelanjutan",
      "Membangun kesadaran dan kepemimpinan local"
    ],
    "correctOption": 1
  },
  {
    "id": 26,
    "q": "Apa indikator utama bahwa sebuah informasi tergolong sebagai hoaks?",
    "options": [
      "Informasinya berasal dari akun resmi lembaga negara",
      "Kontennya mengandung klaim tidak masuk akal dan berasal dari sumber tidak kredibel",
      "Pesannya terlalu netral dan tidak menyinggung isu sensitif",
      "Konten viral yang diunggah oleh akun resmi lembaga negara"
    ],
    "correctOption": 1
  },
  {
    "id": 27,
    "q": "Di bawah ini adalah penyebab kerawanan kampanye bermuatan hoaks, SARA, dan ujaran kebencian di media sosial, kecuali:",
    "options": [
      "Lemahnya regulasi",
      "Lemahnya penegakan hukum",
      "Rendahnya literasi digital masyarakat",
      "Rendahnya literasi digital penyelenggara pemilu"
    ],
    "correctOption": 3
  },
  {
    "id": 28,
    "q": "Manakah di bawah ini yang termasuk bentuk pengawasan partisipatif berbasis digital",
    "options": [
      "penguatan literasi digital",
      "kolaborasi dengan platform dan/atau pengiat media sosial",
      "pelibatan penegak hukum dalam mengawasi media digital",
      "a dan b benar"
    ],
    "correctOption": 3
  },
  {
    "id": 29,
    "q": "Mengapa penggunaan situs seperti Kominfo, TurnBackHoax, dan MAFINDO penting dalam proses verifikasi fakta konten digital selama masa Pemilu?",
    "options": [
      "Karena situs-situs tersebut menyediakan jadwal kampanye resmi dari KPU",
      "Karena situs-situs tersebut mempublikasikan berita politik dari seluruh partai dan langsung diawasi oleh anggota partai",
      "Karena situs-situs tersebut dapat mengklarifikasi apakah suatu informasi termasuk hoaks atau bukan",
      "Karena situs-situs tersebut hanya menampilkan opini publik terhadap kandidat sehingga informasi yang disiarkan dapat dipercaya"
    ],
    "correctOption": 2
  },
  {
    "id": 30,
    "q": "Teknis pengawasan partisipatif berbasis digital adalah sebagai berikut, kecuali?",
    "options": [
      "Menyebarluaskan informasi pemilu secara aktif",
      "Memantau kampanye di media massa",
      "Melaporkan dugaan pelanggaran secara online",
      "Mendeteksi konten hoaks dan ujaran kebencian"
    ],
    "correctOption": 1
  }
];
